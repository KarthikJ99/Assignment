import Person.Farmer;
import Person.WholeSaler;
public class Main {
    
    public static void main(String[] args)  {

        WholeSaler wholeSaler1 = new WholeSaler("Akash Thallam",(long) 1222233344);

        Farmer farmer1 = new Farmer("karthik", (long) 897653421);
        Farmer farmer2 = new Farmer("Suresh", (long) 876565456);
        Farmer farmer3 = new Farmer("Saurav", (long) 324567564);
        Farmer farmer4 = new Farmer("Ganesh", (long) 34228799);
        Farmer farmer5 = new Farmer("Rajesh", (long) 232436557);
        Farmer farmer6 = new Farmer("Kumar", (long) 908876543);
        Farmer farmer7 = new Farmer("Suresh",(long) 765465321);
        Farmer farmer8 = new Farmer("suraj",(long) 232345678);
        try {
            wholeSaler1.addFarmer(farmer1);
            wholeSaler1.addFarmer(farmer2);
            wholeSaler1.addFarmer(farmer3);
            wholeSaler1.addFarmer(farmer4);
            wholeSaler1.addFarmer(farmer5);
            wholeSaler1.addFarmer(farmer6);
            wholeSaler1.addFarmer(farmer7);
            wholeSaler1.addFarmer(farmer8);

        } catch (Exception e) {
            System.out.println("You cannot add more than 6 farmers to the farmers list");
        }

        System.out.println("Farmers_List");
        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        for (Farmer g : wholeSaler1.farmer) {
            System.out.printf("\n Farmer name"+g.getName() +" and Phone number"+g.getContact());
        }

    }

}
